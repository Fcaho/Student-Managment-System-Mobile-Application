package com.uiit.studyhub;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Login screen: email/username + password, with links to Register and Forgot Password.
 */
public class LoginActivity extends AppCompatActivity {

    private EditText etIdentifier;
    private EditText etPassword;
    private UserStore userStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        userStore = new UserStore(this);
        etIdentifier = findViewById(R.id.etIdentifier);
        etPassword = findViewById(R.id.etPassword);
        CheckBox cbShowPassword = findViewById(R.id.cbShowPassword);
        TextView tvForgotPassword = findViewById(R.id.tvForgotPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnGoRegister = findViewById(R.id.btnGoRegister);

        // Show / hide the password text
        cbShowPassword.setOnCheckedChangeListener((buttonView, isChecked) -> {
            etPassword.setTransformationMethod(isChecked
                    ? HideReturnsTransformationMethod.getInstance()
                    : PasswordTransformationMethod.getInstance());
            etPassword.setSelection(etPassword.getText().length());
        });

        btnLogin.setOnClickListener(v -> attemptLogin());

        btnGoRegister.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class)));

        tvForgotPassword.setOnClickListener(v ->
                startActivity(new Intent(LoginActivity.this, ForgotPasswordActivity.class)));
    }

    private void attemptLogin() {
        String identifier = etIdentifier.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (identifier.isEmpty()) {
            Validator.fail(etIdentifier, R.string.error_required);
            return;
        }
        if (password.isEmpty()) {
            Validator.fail(etPassword, R.string.error_required);
            return;
        }

        User user = userStore.authenticate(identifier, password);
        if (user == null) {
            Validator.fail(etPassword, R.string.error_login_failed);
            return;
        }

        userStore.setLoggedInEmail(user.getEmail());
        startActivity(new Intent(LoginActivity.this, DashboardActivity.class));
        finish(); // remove Login from the back stack
    }
}
