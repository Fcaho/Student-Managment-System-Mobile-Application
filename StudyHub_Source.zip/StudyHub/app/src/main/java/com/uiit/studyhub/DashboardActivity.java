package com.uiit.studyhub;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Main screen after login: module cards in a GridLayout.
 * Only "Profile" opens a real screen; the other modules show a "coming soon" message.
 */
public class DashboardActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        User user = new UserStore(this).getLoggedInUser();
        if (user == null) { // not logged in: send the user back to Login
            Intent intent = new Intent(this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            return;
        }

        TextView tvWelcome = findViewById(R.id.tvWelcome);
        tvWelcome.setText(getString(R.string.welcome_user, user.getName()));

        setupModuleCard(R.id.cardCourses, R.string.module_courses);
        setupModuleCard(R.id.cardAssignments, R.string.module_assignments);
        setupModuleCard(R.id.cardSchedule, R.string.module_schedule);
        setupModuleCard(R.id.cardGrades, R.string.module_grades);
        setupModuleCard(R.id.cardNotifications, R.string.module_notifications);

        findViewById(R.id.cardProfile).setOnClickListener(v ->
                startActivity(new Intent(DashboardActivity.this, ProfileActivity.class)));
    }

    /** A module that is not built yet: tapping it shows a short message. */
    private void setupModuleCard(int cardId, int nameRes) {
        View card = findViewById(cardId);
        card.setOnClickListener(v -> Toast.makeText(DashboardActivity.this,
                getString(R.string.module_coming_soon, getString(nameRes)),
                Toast.LENGTH_SHORT).show());
    }
}
