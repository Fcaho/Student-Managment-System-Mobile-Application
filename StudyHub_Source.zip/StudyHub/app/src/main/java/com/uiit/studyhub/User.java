package com.uiit.studyhub;

/**
 * Model class: one registered user.
 */
public class User {

    private final String name;
    private final String email;
    private final String passwordHash;

    public User(String name, String email, String passwordHash) {
        this.name = name;
        this.email = email;
        this.passwordHash = passwordHash;
    }

    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPasswordHash() { return passwordHash; }

    /** Username = the part of the email before the @ sign (e.g. demo@studyhub.com -> demo). */
    public String getUsername() {
        int at = email.indexOf('@');
        return at > 0 ? email.substring(0, at) : email;
    }
}
