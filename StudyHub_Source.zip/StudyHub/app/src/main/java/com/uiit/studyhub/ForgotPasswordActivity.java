package com.uiit.studyhub;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Forgot-password screen. Recovery is SIMULATED: if the email exists we pretend a reset
 * link was sent and open the Reset Password screen (as if the user tapped the link).
 */
public class ForgotPasswordActivity extends AppCompatActivity {

    public static final String EXTRA_EMAIL = "email";

    private EditText etEmail;
    private UserStore userStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        userStore = new UserStore(this);
        etEmail = findViewById(R.id.etEmail);
        Button btnSendReset = findViewById(R.id.btnSendReset);
        Button btnBackToLogin = findViewById(R.id.btnBackToLogin);

        btnSendReset.setOnClickListener(v -> sendResetLink());
        btnBackToLogin.setOnClickListener(v -> finish());
    }

    private void sendResetLink() {
        String email = etEmail.getText().toString().trim();

        if (Validator.fail(etEmail, Validator.checkEmail(email))) return;
        if (!userStore.emailExists(email)) {
            Validator.fail(etEmail, R.string.error_email_not_found);
            return;
        }

        Toast.makeText(this, getString(R.string.msg_reset_link_sent, email),
                Toast.LENGTH_LONG).show();

        Intent intent = new Intent(ForgotPasswordActivity.this, ResetPasswordActivity.class);
        intent.putExtra(EXTRA_EMAIL, email);
        startActivity(intent);
        finish();
    }
}
