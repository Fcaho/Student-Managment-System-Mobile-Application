package com.uiit.studyhub;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;

/**
 * Simulated "backend": stores users and the logged-in session locally in SharedPreferences.
 * No server is needed (allowed by the assignment). Passwords are stored as SHA-256 hashes.
 * NOTE: this is for learning only; a real app must use a secure server and salted hashing.
 */
public class UserStore {

    // Hardcoded demo account (created the first time the app runs)
    public static final String DEMO_NAME = "Demo Student";
    public static final String DEMO_EMAIL = "demo@studyhub.com";
    public static final String DEMO_PASSWORD = "Demo@123";

    private static final String PREFS_NAME = "studyhub_prefs";
    private static final String KEY_USERS = "users";
    private static final String KEY_SESSION = "logged_in_email";

    private final SharedPreferences prefs;

    public UserStore(Context context) {
        prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        if (readUsers().length() == 0) {
            register(DEMO_NAME, DEMO_EMAIL, DEMO_PASSWORD);
        }
    }

    // ---------------------------------------------------------------- users

    public boolean emailExists(String email) {
        return findByEmail(email) != null;
    }

    /** Saves a new user. Returns false if the email is already registered. */
    public boolean register(String name, String email, String password) {
        if (emailExists(email)) return false;
        try {
            JSONArray users = readUsers();
            JSONObject user = new JSONObject();
            user.put("name", name);
            user.put("email", email.toLowerCase(Locale.ROOT));
            user.put("password", hash(email, password));
            users.put(user);
            prefs.edit().putString(KEY_USERS, users.toString()).apply();
            return true;
        } catch (JSONException e) {
            return false;
        }
    }

    /** Checks email-or-username and password. Returns the user, or null if wrong. */
    public User authenticate(String identifier, String password) {
        User user = findByIdentifier(identifier);
        if (user != null && user.getPasswordHash().equals(hash(user.getEmail(), password))) {
            return user;
        }
        return null;
    }

    /** Simulated password reset: replaces the stored password of that email. */
    public boolean updatePassword(String email, String newPassword) {
        try {
            JSONArray users = readUsers();
            for (int i = 0; i < users.length(); i++) {
                JSONObject u = users.getJSONObject(i);
                if (u.getString("email").equalsIgnoreCase(email)) {
                    u.put("password", hash(email, newPassword));
                    prefs.edit().putString(KEY_USERS, users.toString()).apply();
                    return true;
                }
            }
        } catch (JSONException e) {
            // fall through and return false
        }
        return false;
    }

    // -------------------------------------------------------------- session

    public void setLoggedInEmail(String email) {
        prefs.edit().putString(KEY_SESSION, email).apply();
    }

    /** Returns the user who is logged in, or null if nobody is. */
    public User getLoggedInUser() {
        String email = prefs.getString(KEY_SESSION, null);
        return email == null ? null : findByEmail(email);
    }

    public void logout() {
        prefs.edit().remove(KEY_SESSION).apply();
    }

    // -------------------------------------------------------------- helpers

    private User findByEmail(String email) {
        return find(email, false);
    }

    private User findByIdentifier(String identifier) {
        return find(identifier, true);
    }

    private User find(String value, boolean allowUsername) {
        try {
            JSONArray users = readUsers();
            for (int i = 0; i < users.length(); i++) {
                JSONObject u = users.getJSONObject(i);
                User user = new User(u.getString("name"), u.getString("email"),
                        u.getString("password"));
                if (user.getEmail().equalsIgnoreCase(value)
                        || (allowUsername && user.getUsername().equalsIgnoreCase(value))) {
                    return user;
                }
            }
        } catch (JSONException e) {
            // ignore, treated as "not found"
        }
        return null;
    }

    private JSONArray readUsers() {
        try {
            return new JSONArray(prefs.getString(KEY_USERS, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    /** SHA-256 of "email:password", written as hex text. */
    private static String hash(String email, String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(
                    (email.toLowerCase(Locale.ROOT) + ":" + password).getBytes(StandardCharsets.UTF_8));
            StringBuilder hex = new StringBuilder();
            for (byte b : bytes) {
                hex.append(String.format("%02x", b));
            }
            return hex.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }
}
