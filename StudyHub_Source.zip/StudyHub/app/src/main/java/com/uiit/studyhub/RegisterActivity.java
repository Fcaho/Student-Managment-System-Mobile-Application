package com.uiit.studyhub;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Registration screen with full validation (name, email, password, confirm password).
 */
public class RegisterActivity extends AppCompatActivity {

    private EditText etName;
    private EditText etEmail;
    private EditText etPassword;
    private EditText etConfirmPassword;
    private UserStore userStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        userStore = new UserStore(this);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        Button btnRegister = findViewById(R.id.btnRegister);
        Button btnBackToLogin = findViewById(R.id.btnBackToLogin);

        btnRegister.setOnClickListener(v -> attemptRegister());
        btnBackToLogin.setOnClickListener(v -> finish()); // Login is right below in the back stack
    }

    private void attemptRegister() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirm = etConfirmPassword.getText().toString();

        // Validate from top to bottom; stop at the first problem
        if (Validator.fail(etName, Validator.checkName(name))) return;
        if (Validator.fail(etEmail, Validator.checkEmail(email))) return;
        if (Validator.fail(etPassword, Validator.checkPassword(password))) return;
        if (Validator.fail(etConfirmPassword, Validator.checkConfirm(password, confirm))) return;

        if (userStore.emailExists(email)) {
            Validator.fail(etEmail, R.string.error_email_exists);
            return;
        }

        if (userStore.register(name, email, password)) {
            Toast.makeText(this, R.string.msg_register_success, Toast.LENGTH_LONG).show();
            finish(); // back to Login
        }
    }
}
