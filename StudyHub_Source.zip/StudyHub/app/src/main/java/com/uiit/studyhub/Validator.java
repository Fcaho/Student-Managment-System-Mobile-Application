package com.uiit.studyhub;

import android.util.Patterns;
import android.widget.EditText;

/**
 * Input validation rules shared by all screens.
 * Every check returns 0 when the input is valid, otherwise the string-resource id of the error text.
 * (Using string resources means the error messages are translated automatically.)
 */
public final class Validator {

    private Validator() {
        // utility class
    }

    public static int checkName(String name) {
        if (name.isEmpty()) return R.string.error_required;
        if (name.length() < 3) return R.string.error_name_short;
        return 0;
    }

    public static int checkEmail(String email) {
        if (email.isEmpty()) return R.string.error_required;
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) return R.string.error_email_invalid;
        return 0;
    }

    /** Password rule: at least 6 characters, with at least one letter and one digit. */
    public static int checkPassword(String password) {
        if (password.isEmpty()) return R.string.error_required;
        boolean hasLetter = false;
        boolean hasDigit = false;
        for (char c : password.toCharArray()) {
            if (Character.isLetter(c)) hasLetter = true;
            if (Character.isDigit(c)) hasDigit = true;
        }
        if (password.length() < 6 || !hasLetter || !hasDigit) return R.string.error_password_rule;
        return 0;
    }

    public static int checkConfirm(String password, String confirm) {
        if (confirm.isEmpty()) return R.string.error_required;
        if (!confirm.equals(password)) return R.string.error_password_mismatch;
        return 0;
    }

    /**
     * If errorRes is not 0, shows the error on the field, moves focus to it and returns true.
     * Usage:  if (Validator.fail(etEmail, Validator.checkEmail(email))) return;
     */
    public static boolean fail(EditText field, int errorRes) {
        if (errorRes == 0) return false;
        field.setError(field.getContext().getString(errorRes));
        field.requestFocus();
        return true;
    }
}
