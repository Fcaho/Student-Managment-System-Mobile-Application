package com.uiit.studyhub;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Reset-password screen: new password + confirm password with validation.
 */
public class ResetPasswordActivity extends AppCompatActivity {

    private EditText etNewPassword;
    private EditText etConfirmPassword;
    private UserStore userStore;
    private String email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);

        userStore = new UserStore(this);
        email = getIntent().getStringExtra(ForgotPasswordActivity.EXTRA_EMAIL);
        if (email == null) { // opened without an email: nothing to reset
            finish();
            return;
        }

        TextView tvResetInfo = findViewById(R.id.tvResetInfo);
        etNewPassword = findViewById(R.id.etNewPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        Button btnResetPassword = findViewById(R.id.btnResetPassword);

        tvResetInfo.setText(getString(R.string.reset_instruction, email));
        btnResetPassword.setOnClickListener(v -> resetPassword());
    }

    private void resetPassword() {
        String newPassword = etNewPassword.getText().toString();
        String confirm = etConfirmPassword.getText().toString();

        if (Validator.fail(etNewPassword, Validator.checkPassword(newPassword))) return;
        if (Validator.fail(etConfirmPassword, Validator.checkConfirm(newPassword, confirm))) return;

        if (userStore.updatePassword(email, newPassword)) {
            Toast.makeText(this, R.string.msg_password_updated, Toast.LENGTH_LONG).show();
            // Go to Login and clear all earlier screens from the back stack
            Intent intent = new Intent(ResetPasswordActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        }
    }
}
