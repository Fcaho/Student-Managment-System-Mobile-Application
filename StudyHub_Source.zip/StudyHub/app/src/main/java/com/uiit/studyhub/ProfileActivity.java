package com.uiit.studyhub;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Profile screen: shows the logged-in user's information and a Logout button.
 */
public class ProfileActivity extends AppCompatActivity {

    private UserStore userStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        userStore = new UserStore(this);
        User user = userStore.getLoggedInUser();
        if (user == null) {
            goToLogin();
            return;
        }

        TextView tvAvatar = findViewById(R.id.tvAvatar);
        TextView tvProfileName = findViewById(R.id.tvProfileName);
        TextView tvInfoName = findViewById(R.id.tvInfoName);
        TextView tvInfoEmail = findViewById(R.id.tvInfoEmail);
        TextView tvInfoUsername = findViewById(R.id.tvInfoUsername);
        TextView tvInfoStatus = findViewById(R.id.tvInfoStatus);
        Button btnLogout = findViewById(R.id.btnLogout);

        String name = user.getName();
        tvAvatar.setText(name.isEmpty() ? "?" : name.substring(0, 1).toUpperCase());
        tvProfileName.setText(name);
        tvInfoName.setText(name);
        tvInfoEmail.setText(user.getEmail());
        tvInfoUsername.setText(user.getUsername());
        tvInfoStatus.setText(R.string.status_active);

        btnLogout.setOnClickListener(v -> {
            userStore.logout();
            Toast.makeText(this, R.string.logout_success, Toast.LENGTH_SHORT).show();
            goToLogin();
        });
    }

    /** Opens Login and removes every other screen, so Back cannot return to the dashboard. */
    private void goToLogin() {
        Intent intent = new Intent(ProfileActivity.this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }
}
